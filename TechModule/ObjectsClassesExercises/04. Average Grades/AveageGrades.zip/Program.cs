﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.Average_Grades
{
    class Program
    {
        static void Main(string[] args)
        {
            var numberOfStudents = int.Parse(Console.ReadLine());
            var students = new List<Students>();

            for (int i = 0; i < numberOfStudents; i++)
            {
                var input = Console.ReadLine().Split(' ');
                var currentStudent = new Students
                {
                    name = input[0],
                    grades = input.Skip(1).Select(double.Parse).ToList()
                };

            students.Add(currentStudent);
            }

            students = students.Where(value => value.averageGrade >= 5).ToList();
            students = students.OrderBy(value => value.name).ThenByDescending(value => value.averageGrade).ToList();

            foreach (var student in students)
            {
                Console.WriteLine($"{student.name} -> {Math.Round(student.averageGrade,2,MidpointRounding.ToEven):F2}");
            }
        }
    }
}

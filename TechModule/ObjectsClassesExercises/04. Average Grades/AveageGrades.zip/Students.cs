﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.Average_Grades
{
    public class Students
    {
        public string name
        {
            get; set;
        }
        public List<double> grades
        {
            get; set;
        }
        public double averageGrade
        {
            get
            {
                return grades.Average();
            }
        }

        public double GetAvarage(List<double> grades)
        {
            var averageGrades = grades.Average();
            return averageGrade;
        }
    }
}

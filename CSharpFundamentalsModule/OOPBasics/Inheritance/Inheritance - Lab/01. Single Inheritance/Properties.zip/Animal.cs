﻿using System;

class Animal
{
    public void Eat()
    {
        Console.WriteLine("eating...");
    }
}
